# GitHub repository setup checklist

1. Create a **public** repository named `php2shell-safe-exposure-scanner` (or a name you prefer). Do not initialize it with a README or license, because those are already included locally.
2. Upload the files in this project folder, or use Git from a terminal:

   ```bash
   git init
   git add .
   git commit -m "Prepare safe PHP2Shell exposure scanner v1.0.0"
   git branch -M main
   git remote add origin https://github.com/<YOUR-ORG>/php2shell-safe-exposure-scanner.git
   git push -u origin main
   ```

3. In GitHub, open **Settings → General** and add a description such as: `Non-exploit PHP2Shell exposure triage scanner for authorized defensive assessments.`
4. Add suggested topics: `php2shell`, `cve-2026-109618`, `cve-2026-109619`, `security-scanner`, `vulnerability-management`, `defensive-security`, `python`, `excel-report`.
5. Under **Settings → Security**, enable private vulnerability reporting if available. Review Dependabot alerts/security updates according to your maintenance policy.
6. Under **Settings → Branches** (or repository rulesets), protect `main`, require pull-request review if there are multiple maintainers, and require the CI check before merging.
7. Confirm that `targets.txt` contains only comments/examples, and do not upload real reports, organization inventories, or internal scan logs.
8. Check that the Actions workflow passes. Then create a GitHub release tagged `v1.0.0` with notes from `CHANGELOG.md`.
9. After the repository exists, add its CI badge to the README if desired; the exact badge URL depends on the final owner and repository name.

Before publishing, review any local changes and ensure that all assets in scope are yours or covered by written authorization. A public repository makes the code available; it does not grant permission to scan any target.
