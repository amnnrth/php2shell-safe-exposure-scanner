---
name: Feature request
about: Suggest a defensive improvement
title: "[Feature]: "
labels: enhancement
assignees: ''
---

## Problem to solve

## Proposed behavior

## Safety and traffic impact

Would this add requests, expand scope, require credentials, or increase load? How should it remain opt-in and bounded?

## Alternatives considered
