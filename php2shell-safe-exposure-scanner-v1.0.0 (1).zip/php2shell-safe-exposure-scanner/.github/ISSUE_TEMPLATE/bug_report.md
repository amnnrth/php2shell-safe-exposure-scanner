---
name: Bug report
about: Report a reproducible bug in the scanner
title: "[Bug]: "
labels: bug
assignees: ''
---

## Summary

Describe the problem without including sensitive target details.

## Environment

- OS:
- Python version:
- Scanner commit/release:

## Steps to reproduce

Use a local fixture or a target you own/are authorized to assess. Do not include third-party targets, secrets, or internal reports.

## Expected behavior

## Actual behavior

## Sanitized logs / screenshots

Remove hostnames, IPs, cookies, headers, customer data, and other sensitive information before attaching files.
