## Summary

## Testing performed

- [ ] `python -m py_compile php2shell_scan.py`
- [ ] `python -m unittest discover -s tests -v`
- [ ] CLI help checked
- [ ] Tests use local fixtures only; no unauthorized live targets scanned

## Safety and compatibility review

- [ ] No exploit payloads, destructive requests, credential attacks, or stealth/evasion features added
- [ ] Any extra traffic is documented, bounded, and opt-in where appropriate
- [ ] No secrets, target lists, inventories, or scan reports included
- [ ] README/documentation updated if behavior changed
