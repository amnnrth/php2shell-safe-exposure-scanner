"""Unit tests for pure helpers; no network requests or live target scans are made."""
from __future__ import annotations

import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("php2shell_scan", ROOT / "php2shell_scan.py")
scanner = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(scanner)


class TargetParsingTests(unittest.TestCase):
    def test_bare_domain_normalizes_to_https(self):
        self.assertEqual(scanner.normalize_url("Example.COM"), "https://example.com/")

    def test_explicit_scheme_path_query_are_preserved_and_fragment_removed(self):
        self.assertEqual(
            scanner.normalize_url("HTTP://Example.COM:8080/a?q=1#section"),
            "http://example.com:8080/a?q=1",
        )

    def test_markdown_link_uses_destination(self):
        self.assertEqual(
            scanner.normalize_url("[portal](https://example.com/login)"),
            "https://example.com/login",
        )

    def test_credentials_in_url_are_rejected(self):
        with self.assertRaises(ValueError):
            scanner.normalize_url("https://user:pass@example.com/")

    def test_unsupported_scheme_is_rejected(self):
        with self.assertRaises(ValueError):
            scanner.normalize_url("ftp://example.com/file")

    def test_comments_and_duplicates_are_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            target_file = Path(tmp) / "targets.txt"
            target_file.write_text("# comment\nexample.com\nhttps://EXAMPLE.com/\n", encoding="utf-8")
            self.assertEqual(scanner.load_targets(None, str(target_file)), ["https://example.com/"])


class PortParsingTests(unittest.TestCase):
    def test_ports_are_deduplicated(self):
        self.assertEqual(scanner.parse_ports("80,443,80, 8443"), [80, 443, 8443])

    def test_invalid_port_is_rejected(self):
        with self.assertRaises(ValueError):
            scanner.parse_ports("80,65536")

    def test_empty_port_list_is_rejected(self):
        with self.assertRaises(ValueError):
            scanner.parse_ports(", ,")


class VersionTriageTests(unittest.TestCase):
    def test_version_parsing(self):
        self.assertEqual(scanner.parse_php_version("PHP/8.3.36-ubuntu"), (8, 3, 36))
        self.assertIsNone(scanner.parse_php_version("not disclosed"))

    def test_fixed_threshold_is_not_mislabelled_as_unpatched(self):
        assessment, priority, _ = scanner.classify_version("8.3.36")
        self.assertIn("threshold met", assessment.lower())
        self.assertTrue(priority.startswith("P2"))

    def test_version_below_threshold_is_urgent(self):
        assessment, priority, _ = scanner.classify_version("8.3.35")
        self.assertIn("Affected by upstream version range", assessment)
        self.assertTrue(priority.startswith("P0"))

    def test_unknown_version_remains_unverified(self):
        assessment, priority, _ = scanner.classify_version("")
        self.assertIn("not verified", assessment.lower())
        self.assertTrue(priority.startswith("P0"))


class ReportSafetyTests(unittest.TestCase):
    def test_excel_formula_prefix_is_neutralized(self):
        for value in ("=1+1", "+1+1", "-1+1", "@SUM(A1:A2)", "  =1+1"):
            with self.subTest(value=value):
                self.assertTrue(scanner.excel_safe(value).startswith("'"))

    def test_plain_text_and_non_strings_are_unchanged(self):
        self.assertEqual(scanner.excel_safe("Apache/2.4"), "Apache/2.4")
        self.assertEqual(scanner.excel_safe(443), 443)

    def test_report_smoke_and_response_text_is_sanitized(self):
        import datetime
        import openpyxl

        result = {
            "Target URL": "https://example.test/",
            "Hostname": "example.test",
            "PHP2Shell Assessment": "INCONCLUSIVE",
            "Severity / Priority": "P1 - Inventory validation",
            "Assessment Confidence": "Low",
            "Server Header": "=HYPERLINK(\"https://example.invalid\",\"click\")",
            "CVE IDs": scanner.CVE_IDS,
        }
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "report.xlsx"
            scanner.create_report([result], str(output), datetime.datetime.now(datetime.timezone.utc).isoformat(), 0.1)
            self.assertTrue(output.exists())
            workbook = openpyxl.load_workbook(output, data_only=False)
            self.assertEqual(
                workbook["Technical Evidence"]["S2"].value,
                "'=HYPERLINK(\"https://example.invalid\",\"click\")",
            )
            self.assertIn("Executive Dashboard", workbook.sheetnames)
            self.assertIn("Findings Register", workbook.sheetnames)
            self.assertIn("Remediation Tracker", workbook.sheetnames)


if __name__ == "__main__":
    unittest.main()
